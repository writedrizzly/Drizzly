/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.drizzly.springmvc.controller;

import com.drizzly.springmvc.model.DrMaStudent;
import com.drizzly.springmvc.model.IStudent;
import com.drizzly.springmvc.model.IStudentFees;
import com.drizzly.springmvc.model.StudentFees;
import java.util.List;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

/**
 *
 * @author rajaguru
 */
@RestController
public class StudentFeesRestController {
    StudentFacade studentFacade;

    //-------------------Retrieve All Students--------------------------------------------------------
//    @RequestMapping(value = "/studentsfees/{filterData}", method = RequestMethod.GET)
//    public ResponseEntity<List<IStudentFees>> listAllStudent(@PathVariable("filterData") String filterData) {
//        String[] inputs = filterData.split(":");
//        String id = inputs[0];
//        String name = inputs[1];
//        String mobile = inputs[2];
//        String email = inputs[3];
//        String category = inputs[4];
//        System.out.println("id "+id);
//        System.out.println("name "+name);
//        System.out.println("mobile "+mobile);
//        System.out.println("email "+email);
//        System.out.println("category "+category);
//        List<IStudentFees> students = studentFacade.findStudentFees(Long.valueOf(id),name,mobile,email,category);
//        System.out.println("listAllStudents  " + students);
//        if (students.isEmpty()) {
//            return new ResponseEntity<List<IStudentFees>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
//        }
//        ResponseEntity responseEntity = new ResponseEntity<List<IStudentFees>>(students, HttpStatus.FOUND);
//        System.out.println("responseEntity  " + responseEntity.toString());
//        return responseEntity;
//    }


    //------------------- Find a Student --------------------------------------------------------
//    @RequestMapping(value = "/studentsfees/", method = RequestMethod.GET)
//    public ResponseEntity<List<IStudentFees>> findStudentFees(@RequestBody StudentFees student) {
//        System.out.println("findStudentFees User " + student);
//
//        List<IStudentFees> students = studentFacade.findStudentFees(student.getStId(),student.getStName(),student.getStMobile1(),student.getStEmail1(),String.valueOf(student.getStCtId()));
//        System.out.println("listAllStudents  " + students);
//        if (students.isEmpty()) {
//            return new ResponseEntity<List<IStudentFees>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
//        }
//        ResponseEntity responseEntity = new ResponseEntity<List<IStudentFees>>(students, HttpStatus.FOUND);
//        System.out.println("responseEntity  " + responseEntity.toString());
//        return responseEntity;
//
//    }
}
