/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.drizzly.springmvc.fees;

import com.drizzly.springmvc.model.IStudent;
import java.math.BigInteger;
import java.util.Calendar;
import java.util.List;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

/**
 *
 * @author rajaguru
 */
@Component
public class MonthlyFees extends StudentFees{

    MonthlyFees(){}
    public MonthlyFees(final String category) {
        super.calculateFeesHastoBePaid(category);
    }
    
    @Override
    IStudent findStudentsFeesDetail(IStudent student, String category) {
        return feesPending(student);
    }

    @Override
    IStudent feesPending(IStudent student) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(student.getStJoinedDate());
        int joinedMonth = cal.get(Calendar.MONTH  + 1);
        int noOfMonth = curMonth - joinedMonth;
        if(noOfMonth < 0){
            noOfMonth = (12-joinedMonth)+curMonth;
        }else if(noOfMonth == 0){
            noOfMonth = 1;
        }
        BigInteger feesHasToBePaid = student.getStThisMonthFees().multiply(BigInteger.valueOf(noOfMonth));
        BigInteger pendingFeesToPay = feesHasToBePaid.subtract(student.getStPaidTotal());
        student.setStYetToPayTotal(pendingFeesToPay);
        return student;
    }

}
