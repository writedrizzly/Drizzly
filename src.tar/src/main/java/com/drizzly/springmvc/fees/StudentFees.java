/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.drizzly.springmvc.fees;

import com.drizzly.springmvc.model.IFees;
import com.drizzly.springmvc.model.IFeesDue;
import com.drizzly.springmvc.model.IStudent;
import com.drizzly.springmvc.service.StudentDAO;
import java.math.BigInteger;
import java.util.Calendar;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author rajaguru
 */
public abstract class StudentFees {
    
    //@Autowired
    StudentDAO studentDAO=new StudentDAO();
    
    final Calendar now = Calendar.getInstance();
    final int curMonth = now.get(now.MONTH) +1;
    final int curYear = now.get(Calendar.YEAR);
    int finanzialYear = curYear;
    List<IFees> feeses;
    List<IStudent> students;
    
    
   // abstract List<IStudent> findStudentsFeesDetail();
    abstract IStudent findStudentsFeesDetail(final IStudent student, final String category);
    abstract IStudent feesPending(IStudent student);
    
    protected List<IStudent> calculateFeesHastoBePaid(final String category) {
        System.out.println("curMonth  "+curMonth);
        if(curMonth < 5){
            finanzialYear = curYear - 1;
        }
        System.out.println("finanzialYear  "+finanzialYear);
        feeses = studentDAO.getAllFees(finanzialYear);
        students = studentDAO.findStudentsByCategory(category);
        for(IStudent student : students){
            BigInteger totalFeesPaid = BigInteger.ZERO;
            for(IFeesDue feesDue : student.getDrTrFeesDues()){
                System.out.print("feesDue.getFpPaidAmount()"+feesDue.getFpPaidAmount());
                totalFeesPaid = totalFeesPaid.add(feesDue.getFpPaidAmount());
            }
            for(IFees fees : feeses){
                if (Long.parseLong(category) == fees.getDrMaCategory().getCtId()){
                    student.setStThisMonthFees(fees.getFeAmountMonth());
                    student.setStThisYearFees(fees.getFeAmountYear());
                    student.setStThisTearmFees(fees.getFeAmountTerm());
                    break;
                }
            }
            student.setStPaidTotal(totalFeesPaid);
        }
        
        return students;
    }
    
    protected IStudent calculateFeesHastoBePaid(final String category,final IStudent iStudent) {
        System.out.println("curMonth  "+curMonth);
        if(curMonth < 5){
            finanzialYear = curYear - 1;
        }
        System.out.println("finanzialYear  "+finanzialYear);
        feeses = studentDAO.getAllFees(finanzialYear);
        final IStudent student = studentDAO.findStudentsByCategory(category,iStudent);
            BigInteger totalFeesPaid = BigInteger.ZERO;
            for(IFeesDue feesDue : student.getDrTrFeesDues()){
                System.out.print("feesDue.getFpPaidAmount()"+feesDue.getFpPaidAmount());
                totalFeesPaid = totalFeesPaid.add(feesDue.getFpPaidAmount());
            }
            for(IFees fees : feeses){
                if (Long.parseLong(category) == fees.getDrMaCategory().getCtId()){
                    iStudent.setStThisMonthFees(fees.getFeAmountMonth());
                    iStudent.setStThisYearFees(fees.getFeAmountYear());
                    iStudent.setStThisTearmFees(fees.getFeAmountTerm());
                    break;
                }
            }
            iStudent.setStPaidTotal(totalFeesPaid);
        
        return iStudent;
    }
    
    public List<IStudent> findStudentsFees() {
        
        for(IStudent student : students){
            feesPending(student);
        }
        
        return students;
    }
    
}
