/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.drizzly.springmvc.model;

import java.util.Date;
import java.util.Set;

/**
 *
 * @author rajaguru
 */
public interface IEmployee {

    //Set getDrTrLoanDues();

    //Set getDrTrLoans();

    String getEmAddress();

    String getEmCity();

    String getEmCountry();

    String getEmEmail1();

    Date getEmJoinDate();

    String getEmMobile1();

    String getEmMobile2();

    String getEmName();

    String getEmPincode();

    String getEmState();
    
}
