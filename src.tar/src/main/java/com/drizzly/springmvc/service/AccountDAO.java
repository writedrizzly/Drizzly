/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.drizzly.springmvc.service;

import com.drizzly.springmvc.LocalHibernateUtil;
import com.drizzly.springmvc.model.DrTrAccounts;
import com.drizzly.springmvc.model.IAccounts;
import java.util.Date;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.context.annotation.Configuration;

/**
 *
 * @author rajaguru
 */
@Configuration
public class AccountDAO extends AbstractDao {
    final SessionFactory sessionFactory=LocalHibernateUtil.getSessionFactory();
   
    public void saveoOrUpdateAccount(DrTrAccounts accounts) {
        saveOrUpdate(accounts);
    }
    
    public  List<IAccounts> findByDateRange(DrTrAccounts account){
        System.out.print("inside by findByDateRange ");
        getSession().beginTransaction();
        final Criteria criteria = getSession().createCriteria(DrTrAccounts.class);
        criteria.add(Restrictions.between("acDate", account.getAcFromDate(), account.getAcToDate()));
        System.out.print("inside by findByDateRange "+criteria.toString());
        List<IAccounts> accounts =null;
        if(criteria.list() != null){
            accounts = criteria.list();
        }
        getSession().close();
        return accounts;
    }
    
    public  List<IAccounts> findByDateRange(final Date fromDate, final Date toDate){
        System.out.print("inside by findByDateRange ");
        getSession().beginTransaction();
        final Criteria criteria = getSession().createCriteria(DrTrAccounts.class);
        criteria.add(Restrictions.between("acDate", fromDate, toDate));
        System.out.print("inside by findByDateRange "+criteria.toString());
        List<IAccounts> accounts =null;
        if(criteria.list() != null){
            accounts = criteria.list();
        }
        getSession().close();
        return accounts;
    }
}
