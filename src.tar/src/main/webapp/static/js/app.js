'use strict';

var App = angular.module('myApp', ['CustomFilter','tableSort']);
