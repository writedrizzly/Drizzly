'use strict';

App.controller('AccountController', ['$scope', 'AccountService', function ($scope, AccountService) {
    var self = this;
    self.account = {acId:null,acCredit:null,acDebit:'',acCategory:'',acNote:'',acDate:null, acFromDate:null, acToDate:null};
    self.accounts = [];

    self.addAccount = function (account) {
        AccountService.AddAccount(account)
            .then(
                function (data) {
                    self.account = data;
                    console.log("going to fetch Accounts for date "+self.account.acDate);
                    self.findAccount(account.acDate,account.acDate);
                },
                function (errResponse) {
                    console.error('Error while creating account.');
                }
            );
    };

    self.findAccount = function (fromDate,toDate) {
        console.log("findAccount fromDate :: "+fromDate);
        console.log("findAccount toDate   :: "+toDate);
        AccountService.FecthAccount(fromDate,toDate)
            .then(
                function (data) {
                    self.accounts = data;
                },
                function (errResponse) {
                    console.error('Error while fetching Account');
                }
            );
    };

    self.find = function () {
        console.log("find account info")
        self.accounts = [];
        self.findAccount(self.account.acFromDate,self.account.acToDate);
    };
        
    self.submit = function () {
        if (self.account.acId == null) {
            console.log('Saving New account', self.account);
            self.addAccount(self.account);
        } 
        self.reset();
    };

    self.reset = function () {
        self.account = {acId:null,acCredit:null,acDebit:'',acCategory:'',acNote:'',acDate:null, acFromDate:null, acToDate:null};
        $scope.myForm.$setPristine(); //reset Form
    };

}]);
