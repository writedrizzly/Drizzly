'use strict';

App.controller('StudentCFeesController', ['$scope', 'StudentsFeesService', function ($scope, StudentsFeesService) {
        var self = this;
        self.student = {stId: null, drTrFeesDues: [{fpId: null, fpStId: null, fpAmountPaid: 0, fpPaidDate: '', fpMonth: '', fpTerm: '', fpYearly: ''}], drMaCategory: {ctId: null, ctName: ''}, stName: null, stJoinedDate: '', stFeesMode: '', stFatherName: '', stMotherName: '', stRelievedDate: null, stAddress: '', stCity: '', stState: '', stPincode: '', stCountry: '', stMobile1: null, stMobile2: '', stEmail1: null};

        //self.fee = {fpId: null, fpStId: null, fpPaidAmount: '', fpPaidDate: '', fpPaidMode: '', drMaStudent: {stId: null,drTrFeesDues:[{fpId:null,fpStId:null,fpAmountPAid:0,fpPaidDate:'',fpMonth:'',fpTerm:'',fpYearly:''}],drMaCategory:{ctId:null,ctName:''}, stName: '', stJoinedDate: '', stFeesMode: '', stFatherName: '', stMotherName: '', stRelievedDate: '', stAddress: '', stCity: '', stState: '', stPincode: '', stCountry: '', stMobile1: '', stMobile2: '', stEmail1: ''}};
        self.fee = {fpId: null, fpPaidAmount: '', fpPaidDate: '', fpPaidMode: '',drMaStudent: {stId: null,stCtId:null, stName: '', stJoinedDate: '', stFeesMode: '', stFatherName: '', stMotherName: '', stRelievedDate: '', stAddress: '', stCity: '', stState: '', stPincode: '', stCountry: '', stMobile1: '', stMobile2: '', stEmail1: ''}};
        self.category = {id: null, name: ''};
        self.fees = [];
        self.students = [];
        self.categories = [];
//        {
//            console.log(" Students category  ");
//            self.categories = [
//                {id: 1, name: 'PLAY'},
//                {id: 2, name: 'PRE'},
//                {id: 3, name: 'KG1'},
//                {id: 4, name: 'KG2'},
//                {id: 5, name: 'AFTER SCHOOL'},
//                {id: 6, name: 'ABACUS'},
//                {id: 7, name: 'DAYCARE'}
//            ]
//        };
        self.fetchStudentsByCategory = function (categoryId) {
            console.log("find Students belong the categoryId  " + categoryId);
            StudentsFeesService.fetchStudentsByCategory(categoryId)
                    .then(
                            function (data) {
                                self.students = data;
                            },
                            function (errResponse) {
                                console.error('Error while fetching Currencies');
                            }
                    );
        };
        self.fetchAllCategory= function(){
            console.log("find all students category  ");
            StudentsFeesService.fetchAllCategory()
                    .then(
                            function (data) {
                                self.categories = data;
                            },
                            function (errResponse) {
                                console.error('Error while fetching All student Category');
                            }
                    );  
        };
        self.payStudentFees = function (fee) {
            console.log("payStudentFees");
            StudentsFeesService.payStudentFees(fee)
                    .then(
                            self.findStudent(fee.drMaStudent.stId,null,null,null,null),
                            function (errResponse) {
                                console.error('Error while fetching payStudentFees');
                            }
                    );
        };
        
        self.findStudent = function (id,name,mobile,emil,category) {
            console.log("findStudent  :: "+mobile);
            console.log("findStudent id  :: "+id);
            console.log("findStudent category :: "+category);
            StudentsFeesService.findStudentsFees(id,name,mobile,emil,category)
                    .then(
                            function (data) {
                                self.students = data;
                            },
                            function (errResponse) {
                                console.error('Error while fetching findStudent');
                            }
                    );
        };

        self.findstudentsFeesByCategory = function (id,category) {
            console.log("findStudent id  :: "+id);
            console.log("findStudent category :: "+category);
            StudentsFeesService.findstudentsFeesByCategory(id,category)
                    .then(
                            function (data) {
                                self.student = data;
                            },
                            function (errResponse) {
                                console.error('Error while fetching findstudentsFeesByCategory');
                            }
                    );
        };
        
        self.submit = function () {
            self.payStudentFees(self.fee);
            self.reset();
        };

        self.reset = function () {
            self.fee = {fpId: null, fpPaidAmount: '', fpPaidMode: '', fpPaidDate: ''};
            $scope.myForm.$setPristine(); //reset Form
        };

    }]);
