'use strict';
    App.factory('AccountService', ['$http', '$q', function($http, $q){

    return {

        AddAccount: function(account){
        return $http.post('http://localhost:8080/DrizzlyAdmin/accounts/', account)
            .then(
                function(response){
                    return response.data;
                },
                function(errResponse){
                    console.error('Error while creating account');
                    return $q.reject(errResponse);
                }
            );
        },
        FecthAccount: function(fromDate,toDate){
        return $http.get('http://localhost:8080/DrizzlyAdmin/accounts/search/' + fromDate+ '/' + toDate)
            .then(
                function(response){
                    return response.data;
                },
                function(errResponse){
                    console.error('Error while fetching accounts');
                    return $q.reject(errResponse);
                }
            );
        }

    };
}]);
